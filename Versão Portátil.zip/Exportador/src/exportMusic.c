#include "Exports.h"

void exportMusic(void) {
    Wave wav;

    wav = LoadWave("resources/musics/Hydrodinamics.mp3");
    ExportWaveAsCode(wav, "wav_hydrodinamics.h");
    UnloadWave(wav);
}