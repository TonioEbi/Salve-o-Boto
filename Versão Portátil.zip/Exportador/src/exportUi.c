#include "Exports.h"

void exportUi(void) {
    Image img;

    //Menus
    img = LoadImage("resources/images/ui/menu_bg.png");
    ExportImageAsCode(img, "img_menu_bg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/menu_crdts.png");
    ExportImageAsCode(img, "img_menu_crdts.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/menu_ctrls.png");
    ExportImageAsCode(img, "img_menu_ctrls.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/menu_gmov.png");
    ExportImageAsCode(img, "img_menu_gmov.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/menu_pause.png");
    ExportImageAsCode(img, "img_menu_pause.h");
    UnloadImage(img);

    //Buttons
    img = LoadImage("resources/images/ui/bt_menu.png");
    ExportImageAsCode(img, "img_bt_menu.h");
    UnloadImage(img);

    img = LoadImage("resources/images/ui/controles.png");
    ExportImageAsCode(img, "img_controles.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/creditos.png");
    ExportImageAsCode(img, "img_creditos.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/denovo.png");
    ExportImageAsCode(img, "img_denovo.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/jogar.png");
    ExportImageAsCode(img, "img_jogar.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/voltar.png");
    ExportImageAsCode(img, "img_voltar.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/ui/voltar2.png");
    ExportImageAsCode(img, "img_voltar2.h");
    UnloadImage(img);
}