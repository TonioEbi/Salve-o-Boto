#include "Exports.h"

void exportBg(void) {
    Image img;

    //BG
    img = LoadImage("resources/images/sprites/background/sunbg.png");
    ExportImageAsCode(img, "img_sunbg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/moonbg.png");
    ExportImageAsCode(img, "img_moonbg.h");
    UnloadImage(img);

    img = LoadImage("resources/images/sprites/background/cloudhighlightbg.png");
    ExportImageAsCode(img, "img_cloudhighlightbg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/cloudshadowbg.png");
    ExportImageAsCode(img, "img_cloudshadowbg.h");
    UnloadImage(img);

    img = LoadImage("resources/images/sprites/background/cityscapebg.png");
    ExportImageAsCode(img, "img_cityscapebg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/cityoverlaybg.png");
    ExportImageAsCode(img, "img_cityoverlaybg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/waterbg.png");
    ExportImageAsCode(img, "img_waterbg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/floorbg.png");
    ExportImageAsCode(img, "img_floorbg.h");
    UnloadImage(img);

    //FG
    img = LoadImage("resources/images/sprites/background/foamfg.png");
    ExportImageAsCode(img, "img_foamfg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/bubblefg.png");
    ExportImageAsCode(img, "img_bubblefg.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/background/floorfg.png");
    ExportImageAsCode(img, "img_floorfg.h");
    UnloadImage(img);
}