#pragma once

#include "raylib/raylib.h"

extern const int globalPixelWidth;
extern const int globalPixelHeight;
extern const int globalWaterSurfaceHeight;
extern const int globalFloorHeight;
extern int currentWindowScale;
extern int score;
extern int hiscore;