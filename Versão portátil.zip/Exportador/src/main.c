#include "Exports.h"

int main(void) {
    {
        Image img;
        img = LoadImage("resources/images/icon.png");
        ExportImageAsCode(img, "img_icon.h");
        UnloadImage(img);
    }

    exportPlayer();
    exportBg();
    exportUi();
    exportNpc();
    //exportMusic();

    return 0;
}