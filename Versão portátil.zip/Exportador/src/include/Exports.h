#pragma once

#include "raylib/raylib.h"

void exportPlayer(void);
void exportBg(void);
void exportUi(void);
void exportNpc(void);
void exportMusic(void);