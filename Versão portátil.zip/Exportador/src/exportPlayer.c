#include "Exports.h"

void exportPlayer(void) {
    Image img;

    img = LoadImage("resources/images/sprites/diver.png");
    ExportImageAsCode(img, "img_diver.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/diver_attacking.png");
    ExportImageAsCode(img, "img_diver_attacking.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/tank.png");
    ExportImageAsCode(img, "img_tank.h");
    UnloadImage(img);
}