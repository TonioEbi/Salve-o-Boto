#include <stdio.h>
#include "Exports.h"

void exportNpc(void) {
    Image img;

    {
        char file[50];
        char header[50];

        //Animal
        for(int i = 0; i < 17; i++) {
            snprintf(file, sizeof(file), "resources/images/sprites/npc/animal/type_%d.png", i);
            snprintf(header, sizeof(header), "img_animal_%d.h", i);

            img = LoadImage(file);
            ExportImageAsCode(img, header);
            UnloadImage(img);
        }

        //Garbage
        for(int i = 0; i < 11; i++) {
            snprintf(file, sizeof(file), "resources/images/sprites/npc/enemy/type_%d.png", i);
            snprintf(header, sizeof(header), "img_enemy_%d.h", i);

            img = LoadImage(file);
            ExportImageAsCode(img, header);
            UnloadImage(img);
        }
    }

    //Bubble
    img = LoadImage("resources/images/sprites/npc/bubble/bubble_idle.png");
    ExportImageAsCode(img, "img_bubble_idle.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/npc/bubble/bubble_pop.png");
    ExportImageAsCode(img, "img_bubble_pop.h");
    UnloadImage(img);
    
    img = LoadImage("resources/images/sprites/npc/bubble/bubble_breathe.png");
    ExportImageAsCode(img, "img_bubble_breathe.h");
    UnloadImage(img);
}