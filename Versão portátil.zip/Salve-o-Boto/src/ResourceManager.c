/**
 * @file ResourceManager.c
 * @author Prof. Dr. David Buzatto
 * @brief ResourceManager implementation.
 * 
 * @copyright Copyright (c) 2025
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ResourceManager.h"
#include "raylib/raylib.h"

#include "resources/img_icon.h"

#include "resources/img_diver.h"
#include "resources/img_diver_attacking.h"
#include "resources/img_tank.h"

#include "resources/img_animal_0.h"
#include "resources/img_animal_1.h"
#include "resources/img_animal_2.h"
#include "resources/img_animal_3.h"
#include "resources/img_animal_4.h"
#include "resources/img_animal_5.h"
#include "resources/img_animal_6.h"
#include "resources/img_animal_7.h"
#include "resources/img_animal_8.h"
#include "resources/img_animal_9.h"
#include "resources/img_animal_10.h"
#include "resources/img_animal_11.h"
#include "resources/img_animal_12.h"
#include "resources/img_animal_13.h"
#include "resources/img_animal_14.h"
#include "resources/img_animal_15.h"
#include "resources/img_animal_16.h"

#include "resources/img_enemy_0.h"
#include "resources/img_enemy_1.h"
#include "resources/img_enemy_2.h"
#include "resources/img_enemy_3.h"
#include "resources/img_enemy_4.h"
#include "resources/img_enemy_5.h"
#include "resources/img_enemy_6.h"
#include "resources/img_enemy_7.h"
#include "resources/img_enemy_8.h"
#include "resources/img_enemy_9.h"
#include "resources/img_enemy_10.h"

#include "resources/img_bubble_idle.h"
#include "resources/img_bubble_pop.h"
#include "resources/img_bubble_breathe.h"

#include "resources/img_skybg_day.h"
#include "resources/img_citybg_day.h"
#include "resources/img_waterbg.h"
#include "resources/img_floorbg.h"

#include "resources/img_foamfg.h"
#include "resources/img_bubblefg.h"
#include "resources/img_floorfg.h"

#include "resources/img_menu_bg.h"
#include "resources/img_menu_crdts.h"
#include "resources/img_menu_ctrls.h"
#include "resources/img_menu_gmov.h"
#include "resources/img_menu_pause.h"

#include "resources/img_controles.h"
#include "resources/img_jogar.h"
#include "resources/img_creditos.h"
#include "resources/img_voltar.h"
#include "resources/img_bt_menu.h"
#include "resources/img_denovo.h"
#include "resources/img_voltar2.h"

ResourceManager rm = {0};

void loadResourcesResourceManager(void) {
    //Misc. Images
    rm.icon = (Image){IMG_ICON_DATA, IMG_ICON_WIDTH, IMG_ICON_HEIGHT, 1, IMG_ICON_FORMAT};

    //Player
    rm.player = LoadTextureFromImage((Image){IMG_DIVER_DATA, IMG_DIVER_WIDTH, IMG_DIVER_HEIGHT, 1, IMG_DIVER_FORMAT});
    rm.playerAttacking = LoadTextureFromImage((Image){IMG_DIVER_ATTACKING_DATA, IMG_DIVER_ATTACKING_WIDTH, IMG_DIVER_ATTACKING_HEIGHT, 1, IMG_DIVER_ATTACKING_FORMAT});
    rm.oxyTank = LoadTextureFromImage((Image){IMG_TANK_DATA, IMG_TANK_WIDTH, IMG_TANK_HEIGHT, 1, IMG_TANK_FORMAT});

    //NPCs
    rm.animalArray[0] = LoadTextureFromImage((Image){IMG_ANIMAL_0_DATA, IMG_ANIMAL_0_WIDTH, IMG_ANIMAL_0_HEIGHT, 1, IMG_ANIMAL_0_FORMAT});
    rm.animalArray[1] = LoadTextureFromImage((Image){IMG_ANIMAL_1_DATA, IMG_ANIMAL_1_WIDTH, IMG_ANIMAL_1_HEIGHT, 1, IMG_ANIMAL_1_FORMAT});
    rm.animalArray[2] = LoadTextureFromImage((Image){IMG_ANIMAL_2_DATA, IMG_ANIMAL_2_WIDTH, IMG_ANIMAL_2_HEIGHT, 1, IMG_ANIMAL_2_FORMAT});
    rm.animalArray[3] = LoadTextureFromImage((Image){IMG_ANIMAL_3_DATA, IMG_ANIMAL_3_WIDTH, IMG_ANIMAL_3_HEIGHT, 1, IMG_ANIMAL_3_FORMAT});
    rm.animalArray[4] = LoadTextureFromImage((Image){IMG_ANIMAL_4_DATA, IMG_ANIMAL_4_WIDTH, IMG_ANIMAL_4_HEIGHT, 1, IMG_ANIMAL_4_FORMAT});
    rm.animalArray[5] = LoadTextureFromImage((Image){IMG_ANIMAL_5_DATA, IMG_ANIMAL_5_WIDTH, IMG_ANIMAL_5_HEIGHT, 1, IMG_ANIMAL_5_FORMAT});
    rm.animalArray[6] = LoadTextureFromImage((Image){IMG_ANIMAL_6_DATA, IMG_ANIMAL_6_WIDTH, IMG_ANIMAL_6_HEIGHT, 1, IMG_ANIMAL_6_FORMAT});
    rm.animalArray[7] = LoadTextureFromImage((Image){IMG_ANIMAL_7_DATA, IMG_ANIMAL_7_WIDTH, IMG_ANIMAL_7_HEIGHT, 1, IMG_ANIMAL_7_FORMAT});
    rm.animalArray[8] = LoadTextureFromImage((Image){IMG_ANIMAL_8_DATA, IMG_ANIMAL_8_WIDTH, IMG_ANIMAL_8_HEIGHT, 1, IMG_ANIMAL_8_FORMAT});
    rm.animalArray[9] = LoadTextureFromImage((Image){IMG_ANIMAL_9_DATA, IMG_ANIMAL_9_WIDTH, IMG_ANIMAL_9_HEIGHT, 1, IMG_ANIMAL_9_FORMAT});
    rm.animalArray[10] = LoadTextureFromImage((Image){IMG_ANIMAL_10_DATA, IMG_ANIMAL_10_WIDTH, IMG_ANIMAL_10_HEIGHT, 1, IMG_ANIMAL_10_FORMAT});
    rm.animalArray[11] = LoadTextureFromImage((Image){IMG_ANIMAL_11_DATA, IMG_ANIMAL_11_WIDTH, IMG_ANIMAL_11_HEIGHT, 1, IMG_ANIMAL_11_FORMAT});
    rm.animalArray[12] = LoadTextureFromImage((Image){IMG_ANIMAL_12_DATA, IMG_ANIMAL_12_WIDTH, IMG_ANIMAL_12_HEIGHT, 1, IMG_ANIMAL_12_FORMAT});
    rm.animalArray[13] = LoadTextureFromImage((Image){IMG_ANIMAL_13_DATA, IMG_ANIMAL_13_WIDTH, IMG_ANIMAL_13_HEIGHT, 1, IMG_ANIMAL_13_FORMAT});
    rm.animalArray[14] = LoadTextureFromImage((Image){IMG_ANIMAL_14_DATA, IMG_ANIMAL_14_WIDTH, IMG_ANIMAL_14_HEIGHT, 1, IMG_ANIMAL_14_FORMAT});
    rm.animalArray[15] = LoadTextureFromImage((Image){IMG_ANIMAL_15_DATA, IMG_ANIMAL_15_WIDTH, IMG_ANIMAL_15_HEIGHT, 1, IMG_ANIMAL_15_FORMAT});
    rm.animalArray[16] = LoadTextureFromImage((Image){IMG_ANIMAL_16_DATA, IMG_ANIMAL_16_WIDTH, IMG_ANIMAL_16_HEIGHT, 1, IMG_ANIMAL_16_FORMAT});
    
    rm.enemyArray[0] = LoadTextureFromImage((Image){IMG_ENEMY_0_DATA, IMG_ENEMY_0_WIDTH, IMG_ENEMY_0_HEIGHT, 1, IMG_ENEMY_0_FORMAT});
    rm.enemyArray[1] = LoadTextureFromImage((Image){IMG_ENEMY_1_DATA, IMG_ENEMY_1_WIDTH, IMG_ENEMY_1_HEIGHT, 1, IMG_ENEMY_1_FORMAT});
    rm.enemyArray[2] = LoadTextureFromImage((Image){IMG_ENEMY_2_DATA, IMG_ENEMY_2_WIDTH, IMG_ENEMY_2_HEIGHT, 1, IMG_ENEMY_2_FORMAT});
    rm.enemyArray[3] = LoadTextureFromImage((Image){IMG_ENEMY_3_DATA, IMG_ENEMY_3_WIDTH, IMG_ENEMY_3_HEIGHT, 1, IMG_ENEMY_3_FORMAT});
    rm.enemyArray[4] = LoadTextureFromImage((Image){IMG_ENEMY_4_DATA, IMG_ENEMY_4_WIDTH, IMG_ENEMY_4_HEIGHT, 1, IMG_ENEMY_4_FORMAT});
    rm.enemyArray[5] = LoadTextureFromImage((Image){IMG_ENEMY_5_DATA, IMG_ENEMY_5_WIDTH, IMG_ENEMY_5_HEIGHT, 1, IMG_ENEMY_5_FORMAT});
    rm.enemyArray[6] = LoadTextureFromImage((Image){IMG_ENEMY_6_DATA, IMG_ENEMY_6_WIDTH, IMG_ENEMY_6_HEIGHT, 1, IMG_ENEMY_6_FORMAT});
    rm.enemyArray[7] = LoadTextureFromImage((Image){IMG_ENEMY_7_DATA, IMG_ENEMY_7_WIDTH, IMG_ENEMY_7_HEIGHT, 1, IMG_ENEMY_7_FORMAT});
    rm.enemyArray[8] = LoadTextureFromImage((Image){IMG_ENEMY_8_DATA, IMG_ENEMY_8_WIDTH, IMG_ENEMY_8_HEIGHT, 1, IMG_ENEMY_8_FORMAT});
    rm.enemyArray[9] = LoadTextureFromImage((Image){IMG_ENEMY_9_DATA, IMG_ENEMY_9_WIDTH, IMG_ENEMY_9_HEIGHT, 1, IMG_ENEMY_9_FORMAT});
    rm.enemyArray[10] = LoadTextureFromImage((Image){IMG_ENEMY_10_DATA, IMG_ENEMY_10_WIDTH, IMG_ENEMY_10_HEIGHT, 1, IMG_ENEMY_10_FORMAT});

    rm.bubbleIdle = LoadTextureFromImage((Image){IMG_BUBBLE_IDLE_DATA, IMG_BUBBLE_IDLE_WIDTH, IMG_BUBBLE_IDLE_HEIGHT, 1, IMG_BUBBLE_IDLE_FORMAT});
    rm.bubblePop = LoadTextureFromImage((Image){IMG_BUBBLE_POP_DATA, IMG_BUBBLE_POP_WIDTH, IMG_BUBBLE_POP_HEIGHT, 1, IMG_BUBBLE_POP_FORMAT});
    rm.bubbleBreathe = LoadTextureFromImage((Image){IMG_BUBBLE_BREATHE_DATA, IMG_BUBBLE_BREATHE_WIDTH, IMG_BUBBLE_BREATHE_HEIGHT, 1, IMG_BUBBLE_BREATHE_FORMAT});

    //Game BGs
    rm.skyBgDay = LoadTextureFromImage((Image){IMG_SKYBG_DAY_DATA, IMG_SKYBG_DAY_WIDTH, IMG_SKYBG_DAY_HEIGHT, 1, IMG_SKYBG_DAY_FORMAT});
    rm.cityBgDay = LoadTextureFromImage((Image){IMG_CITYBG_DAY_DATA, IMG_CITYBG_DAY_WIDTH, IMG_CITYBG_DAY_HEIGHT, 1, IMG_CITYBG_DAY_FORMAT});
    rm.waterBg = LoadTextureFromImage((Image){IMG_WATERBG_DATA, IMG_WATERBG_WIDTH, IMG_WATERBG_HEIGHT, 1, IMG_WATERBG_FORMAT});
    rm.floorBg = LoadTextureFromImage((Image){IMG_FLOORBG_DATA, IMG_FLOORBG_WIDTH, IMG_FLOORBG_HEIGHT, 1, IMG_FLOORBG_FORMAT});

    //Game FGs
    rm.foamFg = LoadTextureFromImage((Image){IMG_FOAMFG_DATA, IMG_FOAMFG_WIDTH, IMG_FOAMFG_HEIGHT, 1, IMG_FOAMFG_FORMAT});
    rm.bubbleFg = LoadTextureFromImage((Image){IMG_BUBBLEFG_DATA, IMG_BUBBLEFG_WIDTH, IMG_BUBBLEFG_HEIGHT, 1, IMG_BUBBLEFG_FORMAT});
    rm.floorFg = LoadTextureFromImage((Image){IMG_FLOORFG_DATA, IMG_FLOORFG_WIDTH, IMG_FLOORFG_HEIGHT, 1, IMG_FLOORFG_FORMAT});

    //Menus
    rm.menuBg = LoadTextureFromImage((Image){IMG_MENU_BG_DATA, IMG_MENU_BG_WIDTH, IMG_MENU_BG_HEIGHT, 1, IMG_MENU_BG_FORMAT}); 
    rm.menuCredits = LoadTextureFromImage((Image){IMG_MENU_CRDTS_DATA, IMG_MENU_CRDTS_WIDTH, IMG_MENU_CRDTS_HEIGHT, 1, IMG_MENU_CRDTS_FORMAT});
    rm.menuControls = LoadTextureFromImage((Image){IMG_MENU_CTRLS_DATA, IMG_MENU_CTRLS_WIDTH, IMG_MENU_CTRLS_HEIGHT, 1, IMG_MENU_CTRLS_FORMAT});
    rm.menuGameOver = LoadTextureFromImage((Image){IMG_MENU_GMOV_DATA, IMG_MENU_GMOV_WIDTH, IMG_MENU_GMOV_HEIGHT, 1, IMG_MENU_GMOV_FORMAT});
    rm.menuPause = LoadTextureFromImage((Image){IMG_MENU_PAUSE_DATA, IMG_MENU_PAUSE_WIDTH, IMG_MENU_PAUSE_HEIGHT, 1, IMG_MENU_PAUSE_FORMAT});

    //Buttons
    rm.controlsButton = LoadTextureFromImage((Image){IMG_CONTROLES_DATA, IMG_CONTROLES_WIDTH, IMG_CONTROLES_HEIGHT, 1, IMG_CONTROLES_FORMAT});
    rm.playButton = LoadTextureFromImage((Image){IMG_JOGAR_DATA, IMG_JOGAR_WIDTH, IMG_JOGAR_HEIGHT, 1, IMG_JOGAR_FORMAT});
    rm.creditsButton = LoadTextureFromImage((Image){IMG_CREDITOS_DATA, IMG_CREDITOS_WIDTH, IMG_CREDITOS_HEIGHT, 1, IMG_CREDITOS_FORMAT});
    rm.backButton = LoadTextureFromImage((Image){IMG_VOLTAR_DATA, IMG_VOLTAR_WIDTH, IMG_VOLTAR_HEIGHT, 1, IMG_VOLTAR_FORMAT});
    rm.menuButton = LoadTextureFromImage((Image){IMG_BT_MENU_DATA, IMG_BT_MENU_WIDTH, IMG_BT_MENU_HEIGHT, 1, IMG_BT_MENU_FORMAT});
    rm.againButton = LoadTextureFromImage((Image){IMG_DENOVO_DATA, IMG_DENOVO_WIDTH, IMG_DENOVO_HEIGHT, 1, IMG_DENOVO_FORMAT});
    rm.backButton2 = LoadTextureFromImage((Image){IMG_VOLTAR2_DATA, IMG_VOLTAR2_WIDTH, IMG_VOLTAR2_HEIGHT, 1, IMG_VOLTAR2_FORMAT});

    rm.bg_tune = LoadMusicStream("resources/musics/Hydrodinamics.mp3");
}

void unloadResourcesResourceManager(void) {
    UnloadMusicStream( rm.bg_tune );
}